from django.contrib import admin
from .models import UserBot, SponserChannel



admin.site.register(UserBot)
admin.site.register(SponserChannel)


