

MESSAGES = {
    'HOME_STEP_USER': 'به ربات اینستا دانلودر خوش امدید . 🌹',
    'MSG_JOIN_MY_CHANNEL': 'برای استفاده از ربات میبایست در کانال اسپانسری ما عضو باشید 🌹\n',
    'MSG_INSTA_DOWNLOAD_HOME': """●╔══ [ instagram Downloader ]
●╠  1️⃣  Post Downloader   
●╠═══ [ Normal Post
●╠ https://insta.com/p/xxx/
●╠═══  [ Reel  Post 
●╠ https://insta.com/reel/xxx/
●╠  2️⃣  Stori Downloader
●╠═══ [ Stori @IIIllIlll
●╠ @IIIllIlll
●╠  3️⃣  Igtv Downloader
●╠═══ [  Igtv link
●╠ https://insta.com/tv/xxx/
●╚═══════════════════════""",

    'MSG_CUNTACT_US': """متن خود را ارسال کنید
لطفا فقط پیغام خود را در قالب یک مسیج ارسال کنید
⏱ ساعت پاسخگویی :‌از ساعت 7 صب تا ساعت 1 شب . ✅
\n⛔️ توجه داشته باشید برای اینکه با پشتیبانی چت کنید حتما حتما در همین مرحله باقی بمانید و دکمه \"بازگشت🏛\" را نزنید. 
‌‌‌
""",
    'TEST':'Just For Test',
    'MSG_SUPPORTED_FORWARD_ADMIN': "user id : <code>{}</code>\nname : <code>{}</code>\nusername : <code>{}</code>",
    'MSG_HOME_STEP_ADMIN': 'Wellcomee Admin 👮‍♀️',
    'MSG_CALLBACK_IS_JOIN':'شما عضو نیستید . لطفا عضو شوید.',
    'MSG_CALLBACK_USER_BLOCKED':'کاربر {} بلاک شد ✅',
    'MSG_CALLBACK_USER_BLOCKED':'کاربر {} ازاد شد ✅',
    'MSG_LINK_NOTVALID_BLOCKED':'لینک نامعتبر ⛔️',
    'MSG_LINKS_POSTS':'<a href="{}">.</a>',
    'MSG_USERS_INFO_ADMIN':'Users Count : <code>{}</code>',
    'MSG_SPONSER_ADD_ADMIN':'To add a channel please send us your channel \nExample : @S3curity_Gray\n',
    'MSG_SPONSER_DEL_ADMIN':'To delete a channel please send us your channel \nExample : @S3curity_Gray\n',
    'MSG_SPONSER_ADMIN':'To add a channel please send us your channel \nExample : @S3curity_Gray\nSponser List Cannel : \n\n',
    'MSG_ADD_SPONSER_SUCCESS_ADMIN':'Channel @{} Added Success ✅',
    'MSG_DEL_SPONSER_SUCCESS_ADMIN':'Channel @{} Deleteed Success ✅',
    'MSG_SPONSER_NOT_FOUND_ADMIN':'Channel @{} Not Found In Sponser List ⛔️',
    'MSG_ADD_SPONSER_ERROE_ADMIN':'Channel @{} Exists ⛔️',
    'MSG_TABLIQ_MENU_ADMIN':'Choose One of The Advertisements',
    'MSG_TABLIQ_MENU_MSEGES_ADMIN':'Send Me Your Advertisements',
    'MSG_TABLIQ_SENDEID_SUCCESS_ADMIN':'Advertisements End ✅',
    'MSG_TABLIQ_WAITING_ADMIN':'Please Waite Advertise Sended Soon ⏳',
}